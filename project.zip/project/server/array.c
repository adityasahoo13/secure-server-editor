An array is a systematic arrangement of similar objects, usually in rows and columns.
