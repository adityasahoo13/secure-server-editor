hello sir i am main . c
i am editing the file content 
